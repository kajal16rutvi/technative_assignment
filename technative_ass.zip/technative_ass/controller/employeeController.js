const express=require('express');
const req = require('express/lib/request');
const res = require('express/lib/response');
const { Mongoose } = require('mongoose');
const Employee=Mongoose.model('Employee');

var router=express.Router();
router.get('/',(req,res)=>{
    res.render("employee/addOrEdit",{
        viewTitle:"insert employee"
    });
});

router.post('/',(req,res)=>{
    if(req.body._id=='')
    insertRecord(req,res);
    else
    updateRecord(req,res);
    });
    function insertRecord(req,res){
        var employee=new Employee();
        employee.firstName=req.body.firstName;
        employee.LastName=req.body.lastName;
        employee.email=req.body.email;
        employee.mobile=req.body.mobile;
        employee.save((err,doc)=>{
            if(!err)
            res.redirect('employee/list');
            else{
                if(err.name==validationError){
                    handleValidationError(err.req.body);
                    res.render("employee/addOrEdit",{
                        viewTitle:"insert employee"
                        employee:req.body
                    });
                }
                console.log('error during record insertion:'+err);
            }
        });

    }
    function updateRecord(req,res){
        Employee.findOneAndUpdate({_id:req.body._id},{new: true},(err,docs)=>{
            if(!err){err.redirect('employee/list');}
            else{
                if(err.name=='validationError'){
                    handleValidationError(err,req.body);
                    res.render("employee/addOrEdit",{
                        viewTitle:"update employee",
                        employee:req.body
                    });
                }
                else
                console.log('error during record update:'+err);
            }
        });
    }
    router.get('/list',(req,res)=>{
        res.json('from list');
        Employee.find((err,docs)=>{
            if(!err){
                res.render("employee/list",list: {
                    docs
            
        });
    }
    });
    function handleValidationError(err,body){
        for(field in err.errors)
        {
            switch(err.errors[field].path){
                case 'firstName':
                    body['firstNameError']=err.errors[field].message;
                    break;
                    case 'email':
                        body['emailError']=err.errors[field].message;
                        break;
                        default:
                            break;
            }
        }
    }
    router.get('/:id',(req,res)=>{
        Employee.findById(req.params.id,(err,doc)=>{
            if(!err){
                res.render("employee/addOrEdit",{
                    viewTitle:"update employee",
                    employee:doc
                });
            }

        });

    });
    router.get('/delete/:id',(req,res)=>{
        Employee.findByIdAndRemove(req.params.id,(err,doc)=>{
            if(!err){
                res.redirect('/employee/list');
            }
            else{
                console.log('error in employee delete:'+err);
            }
        });
    });
module.exports=router;