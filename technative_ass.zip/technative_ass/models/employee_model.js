const mongoose=require('mongoose');
const { required } = require('nodemon/lib/config');
var employeeSchema= new mongoose.Schema({
    firstName:{
        type:String
        required:'this field is required'
    },
    email:{
        type:String
    },
    mobile:{
        type:String
    }
});
employeeSchema.path('email').validate((val)=>{
    emailRegex=/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)"))|(".+"))@((\[0-9]{1,3}\.[0-9]{1,3}));
    return emailRegex.test(val);

},'invalid email.');
mongoose.model('Employee',employeeSchema);