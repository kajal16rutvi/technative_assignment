const mongoose=require('mongoose');
mongoose.connect('mongodb://localhost:27017/EmployeeDB',{useNewUrlParser:true},(err)=>{
if(!err){ console.log('MongoDB connection suucceeded')}
else{ console.log('Error inD DB connection:'+err)}
});
require('./employee_model');